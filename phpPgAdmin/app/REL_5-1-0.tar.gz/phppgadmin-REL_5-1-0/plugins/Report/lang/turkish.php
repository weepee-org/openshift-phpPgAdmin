<?php
	/**
	 * Turkish language file.
	 */

	// Basic
	$plugin_lang['strplugindescription'] = 'Report plugin';
	$plugin_lang['strnoreportsdb']  =  'reports veritabanı yaratışmamış. Yönergeler için lütfen INSTALL dosyasını okuyunuz.';

	// Reports
	$plugin_lang['strreport'] = 'Rapor';
	$plugin_lang['strreports'] = 'Raporlar';
	$plugin_lang['strshowallreports'] = 'Tüm raporları göster';
	$plugin_lang['strnoreports'] = 'Hiçbir rapor bulunamadı';
	$plugin_lang['strcreatereport'] = 'Rapor yaratıldı.';
	$plugin_lang['strreportdropped'] = 'Rapor silindi';
	$plugin_lang['strreportdroppedbad'] = 'Rapor silme işi başarısız oldu.';
	$plugin_lang['strconfdropreport'] = '"%s" raporunu silmek istediğinize emin misiniz?';
	$plugin_lang['strreportneedsname'] = 'Raporunuza bir ad vermelisiniz.';
	$plugin_lang['strreportneedsdef'] = 'Raporunuz için SQL sorguları yazmalısınız.';
	$plugin_lang['strreportcreated'] = 'Rapor kaydedildi.';
	$plugin_lang['strreportcreatedbad'] = 'Rapor kaydetme başarısız oldu.';
?>
